<?php
/**
 * Theme App Index
 * Main loader for theme app directory
 */

include __DIR__ . '/bootstrap.php';
