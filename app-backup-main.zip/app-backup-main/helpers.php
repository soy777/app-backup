<?php
/**
 * Helper functions for theme app
 */

function app_helper_sample(){
    return "This is a helper function";
}
